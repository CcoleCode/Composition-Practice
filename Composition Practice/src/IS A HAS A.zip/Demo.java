/*
 * Author: Chelsea Cole
 * Date: March 14, 2022
 * IS A / HAS A Relationship Assignment
 * 
 */


public class Demo {

	public static void main(String[] args) {
		
		Engine e = new Engine(6, "400 horsepower");
		
		Wheel[] wheel = new Wheel[4];
		
		Car c = new Car(null, 0, null, 0, null, 0, e, null);
		
		e.start();
		
	//	wheel[2] = Wheel.getSizeInInches("wheel");
		
		//System.out.println(wheel[2].getSizeInInches("wheel"));
		
		System.out.println("Type of tank: " + c.getTypeOfTank());
		
		System.out.println("Seating Capacity: " + c.getSeatingCapacity());
		
		e.stop();

	}

}
